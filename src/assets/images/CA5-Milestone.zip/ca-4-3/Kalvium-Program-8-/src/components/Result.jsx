import React from 'react';
// import React, { useState, useEffect } from 'react';

const Result = ({ score, len, restartQuiz }) => {
const percentage = (score / len) * 100;

let message;
if (percentage > 50) {
  message = "Great job!";
} else {
  message = "Better luck next time!";
}

return (
  <div className="result-box">
    <h2>Quiz Completed!</h2>
    <p>Your Score: {score} / {len}</p>
    <p>{message}</p>
    <button className="restart-btn" onClick={restartQuiz}>
      Restart Quiz
    </button>
  </div>
);

};

export default Result;
