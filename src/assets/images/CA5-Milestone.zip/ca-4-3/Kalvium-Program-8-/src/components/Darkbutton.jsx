import  { useState } from 'react';
import './Darkbutton.css';

function Darkbutton() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const toggleDarkMode = () => {
    setIsDarkMode((prevMode) => !prevMode);
  
    if (!isDarkMode) {
      document.body.style.backgroundColor = 'rgb(24, 24, 24)'; // Dark mode background
      document.body.style.color = 'rgb(240, 240, 240)';       // Dark mode text color
    } else {
      document.body.style.backgroundColor = 'rgb(240, 240, 240)'; // Light mode background
      document.body.style.color = 'rgb(0, 0, 0)';                // Light mode text color
    }
  };
  

  return (
    <div className="toggle-container">
      <label className="switch">
        <input
          type="checkbox"
          checked={isDarkMode}
          onChange={toggleDarkMode}
          aria-label="Toggle Dark Mode"
        />
        <span className="slider round"></span>
      </label>
    </div>
  );
}

export default Darkbutton;
